import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final Color primaryColor = Color(0xFF4CAF50);
  final Color accentColor = Color(0xFF81C784);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Modern UI App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: primaryColor,
        colorScheme: ColorScheme.fromSwatch().copyWith(secondary: accentColor),
        textTheme: TextTheme(
          bodyMedium: TextStyle(fontFamily: 'Roboto', fontSize: 16),
        ),
      ),
      home: Page1(),
    );
  }
}

class Page1 extends StatefulWidget {
  @override
  _Page1State createState() => _Page1State();
}

class _Page1State extends State<Page1> {
  bool isChecked = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Welcome'),
        elevation: 5,
        backgroundColor: Colors.teal,
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Choose Your Favorite Image',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.teal),
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _roundedImage('https://images.pexels.com/photos/31108436/pexels-photo-31108436/free-photo-of-beautiful-cherry-blossom-tree-in-spring-landscape.jpeg?auto=compress&cs=tinysrgb&w=400'),
                _roundedImage('https://images.pexels.com/photos/31109292/pexels-photo-31109292/free-photo-of-delicate-purple-crocus-flowers-blooming-in-pavement.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'),
              ],
            ),
            SizedBox(height: 20),
            if (!isChecked)
              TextField(
                decoration: InputDecoration(
                  hintText: 'Type something...',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  filled: true,
                  fillColor: Colors.grey.shade100,
                ),
              ),
            CheckboxListTile(
              title: Text('Vanishes if checked'),
              value: isChecked,
              onChanged: (value) => setState(() => isChecked = value!),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => Page2()));
              },
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                backgroundColor: const Color.fromARGB(255, 183, 192, 191),
              ),
              child: Text('Next Page'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _roundedImage(String url) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(15),
      child: Image.network(url, width: 150, height: 150, fit: BoxFit.cover),
    );
  }
}

class Page2 extends StatefulWidget {
  @override
  _Page2State createState() => _Page2State();
}

class _Page2State extends State<Page2> {
  double sliderValue = -20;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Adjust Slider'),
        backgroundColor: Colors.teal,
        elevation: 5,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Adjust the value', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Slider(
              min: -20,
              max: 400,
              divisions: 21,
              value: sliderValue,
              activeColor: Colors.teal,
              onChanged: (value) => setState(() => sliderValue = value),
            ),
            Text('Value: ${sliderValue.toStringAsFixed(1)}'),
            SizedBox(height: 20),
            _roundedImage('https://images.pexels.com/photos/250591/pexels-photo-250591.jpeg?auto=compress&cs=tinysrgb&w=600'),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => Page3())),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              ),
              child: Text('Next Page'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _roundedImage(String url) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(15),
      child: Image.network(url, width: 200, height: 200, fit: BoxFit.cover),
    );
  }
}

class Page3 extends StatefulWidget {
  @override
  _Page3State createState() => _Page3State();
}

class _Page3State extends State<Page3> {
  final TextEditingController _controller = TextEditingController();
  List<String> friends = ['Shahin', 'Rafi', 'Shahriar', 'John Doe'];

  void _addFriend() {
    if (_controller.text.trim().isNotEmpty) {
      setState(() {
        friends.add(_controller.text.trim());
        _controller.clear();
      });
    }
  }

  void _removeFriend(int index) {
    setState(() => friends.removeAt(index));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Friend List'),
        backgroundColor: Colors.teal,
        elevation: 5,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      hintText: 'Enter friend name',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      filled: true,
                      fillColor: Colors.grey.shade100,
                    ),
                  ),
                ),
                SizedBox(width: 10),
                ElevatedButton(
                  onPressed: _addFriend,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: Text('Add'),
                ),
              ],
            ),
            SizedBox(height: 15),
            Expanded(
              child: ListView.builder(
                itemCount: friends.length,
                itemBuilder: (context, index) => Card(
                  elevation: 4,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: ListTile(
                    leading: Icon(Icons.person, color: Colors.teal),
                    title: Text(friends[index]),
                    trailing: IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _removeFriend(index),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: 10),
            _roundedImage('https://images.pexels.com/photos/31098320/pexels-photo-31098320/free-photo-of-bouquet-of-yellow-mimosa-flowers-on-grey-armchair.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'),
          ],
        ),
      ),
    );
  }

  Widget _roundedImage(String url) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(15),
      child: Image.network(url, width: 200, height: 200, fit: BoxFit.cover),
    );
  }
}
